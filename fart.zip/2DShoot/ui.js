function displayUI() {
  fill(255);
  textSize(18);
  text(`Ammo: ${ammo}`, 20, 30);
  text(`Score: ${score}`, 20, 60);
}
